# BrazTV Player — starter Android

Projeto inicial Kotlin + Media3/ExoPlayer, tema vermelho/preto, carregamento remoto M3U/M3U8 por HTTPS e consulta Xtream Codes básica para canais ao vivo.

## Compilar APK pelo celular
1. Crie um repositório no GitHub pelo navegador Android.
2. Envie todos os arquivos e pastas deste projeto preservando a estrutura.
3. Abra Actions e permita workflows se solicitado.
4. Execute **Build BrazTV Player APK** com **Run workflow**.
5. Baixe o artifact `BrazTVPlayer-debug-apk`, extraia e instale `app-debug.apk`.

## Incluído
- Player integrado Media3/ExoPlayer.
- Lista M3U/M3U8 remota por HTTPS.
- Consulta Xtream `get_live_streams`.
- Pesquisa simples e compilação remota do APK debug.

## Limitações e segurança
- É uma base inicial que precisa ser compilada e testada; ainda não é um APK pré-compilado.
- Xtream endpoint `/live/...ts` pode variar por provedor.
- Importação de arquivo local, EPG, filmes/séries, favoritos persistentes e armazenamento seguro de credenciais ainda não estão implementados.
- Use apenas listas e servidores para os quais você tem autorização.
- Não existe compatibilidade universal: codecs, DRM, autenticação e protocolos podem impedir a reprodução.
- O projeto exige HTTPS. Antes de distribuir, implemente armazenamento seguro, política de privacidade, validação de URLs, testes e assinatura de release.
