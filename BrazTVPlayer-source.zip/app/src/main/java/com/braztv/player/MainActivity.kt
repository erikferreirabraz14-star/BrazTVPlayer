package com.braztv.player

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.net.Uri
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

data class Channel(val name:String, val url:String, val group:String="Lista")

class MainActivity: Activity() {
 private val red=Color.rgb(242,13,32); private val bg=Color.rgb(10,10,12)
 private val panel=Color.rgb(27,27,31); private val muted=Color.LTGRAY
 private val io=Executors.newSingleThreadExecutor()
 private var player:ExoPlayer?=null
 private lateinit var playerView:PlayerView; private lateinit var status:TextView
 private lateinit var listBox:LinearLayout; private lateinit var m3u:EditText
 private lateinit var host:EditText; private lateinit var user:EditText; private lateinit var pass:EditText
 private lateinit var search:EditText
 private val channels=mutableListOf<Channel>()

 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); buildUi()
  player=ExoPlayer.Builder(this).build(); playerView.player=player
  player?.addListener(object:Player.Listener { override fun onPlayerError(error:PlaybackException) { setStatus("Falha na reprodução. Confira URL, acesso e formato.") } })
 }
 private fun buildUi() {
  val root=LinearLayout(this).apply { orientation=1; setBackgroundColor(bg); setPadding(dp(14),dp(10),dp(14),dp(12)) }
  root.addView(TextView(this).apply { text="▶  BrazTV PLAYER"; textSize=24f; setTextColor(red); typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER_VERTICAL; setPadding(0,dp(8),0,dp(8)) })
  root.addView(TextView(this).apply { text="Reprodutor de listas autorizadas"; textSize=13f; setTextColor(muted) })
  playerView=PlayerView(this).apply { useController=true; setBackgroundColor(Color.BLACK) }
  root.addView(playerView,LinearLayout.LayoutParams(-1,dp(205)).apply { topMargin=dp(10); bottomMargin=dp(8) })
  val scroll=ScrollView(this); val form=LinearLayout(this).apply { orientation=1 }
  m3u=edit("URL HTTPS da lista M3U/M3U8"); form.addView(m3u)
  form.addView(button("Carregar lista M3U") { loadM3u(m3u.text.toString().trim()) })
  host=edit("Servidor HTTPS (ex.: https://servidor.example)")
  user=edit("Usuário"); pass=edit("Senha").apply { inputType=129 }
  form.addView(host); form.addView(user); form.addView(pass)
  form.addView(button("Carregar canais Xtream") { loadXtream(host.text.toString().trim(),user.text.toString().trim(),pass.text.toString()) })
  search=edit("Pesquisar canal"); form.addView(search)
  form.addView(button("Pesquisar") { render(search.text.toString().trim()) })
  status=TextView(this).apply { text="Pronto. Adicione uma lista ou servidor autorizado."; textSize=13f; setTextColor(muted); setPadding(0,dp(8),0,dp(8)) }
  form.addView(status); listBox=LinearLayout(this).apply { orientation=1 }; form.addView(listBox)
  scroll.addView(form); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
 }
 private fun loadM3u(url:String) {
  if(!url.startsWith("https://",true)) { setStatus("Informe uma URL HTTPS M3U/M3U8 autorizada."); return }
  setStatus("Carregando lista…")
  io.execute { try { val parsed=parseM3u(fetch(url)); runOnUiThread { channels.clear(); channels.addAll(parsed); render(""); setStatus("Itens carregados: ${parsed.size}") } }
   catch(e:Exception) { setStatus("Falha ao carregar: ${e.message ?: "erro de rede"}") } }
 }
 private fun parseM3u(text:String):List<Channel> {
  val out=mutableListOf<Channel>(); var name="Canal"; var group="Lista"
  text.lineSequence().forEach { raw ->
   val line=raw.trim()
   if(line.startsWith("#EXTINF",true)) {
    name=line.substringAfterLast(",").trim().ifBlank { "Canal" }
    group=Regex("group-title=\\\"([^\\\"]*)\\\"",RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1) ?: "Lista"
   } else if(line.startsWith("https://",true)) out.add(Channel(name,line,group))
  }
  return out
 }
 private fun loadXtream(hostInput:String, u:String, p:String) {
  if(hostInput.isBlank()||u.isBlank()||p.isBlank()) { setStatus("Preencha servidor, usuário e senha."); return }
  val h=hostInput.trimEnd('/')
  if(!h.startsWith("https://",true)) { setStatus("Use HTTPS sempre que disponível."); return }
  setStatus("Consultando servidor…")
  io.execute { try {
   val api="$h/player_api.php?username=${enc(u)}&password=${enc(p)}&action=get_live_streams"
   val data=JSONArray(fetch(api)); val parsed=mutableListOf<Channel>()
   for(i in 0 until data.length()) { val item=data.getJSONObject(i); val id=item.optString("stream_id")
    if(id.isNotBlank()) parsed.add(Channel(item.optString("name","Canal"),"$h/live/${enc(u)}/${enc(p)}/$id.ts",item.optString("category_name","Ao vivo")))
   }
   runOnUiThread { channels.clear(); channels.addAll(parsed); render(""); setStatus("Canais carregados: ${parsed.size}. O formato pode variar por servidor.") }
  } catch(e:Exception) { setStatus("Erro Xtream: ${e.message ?: "verifique os dados"}") } }
 }
 private fun render(filter:String) {
  listBox.removeAllViews()
  val found=channels.filter { it.name.contains(filter,true)||it.group.contains(filter,true) }.take(500)
  if(found.isEmpty()) { listBox.addView(TextView(this).apply { text=if(channels.isEmpty()) "Nenhum canal carregado." else "Nenhum resultado."; setTextColor(muted) }); return }
  found.forEach { c ->
   val row=LinearLayout(this).apply { orientation=1; setBackgroundColor(panel); setPadding(dp(12),dp(10),dp(12),dp(10)) }
   row.addView(TextView(this).apply { text=c.name; textSize=15f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD })
   row.addView(TextView(this).apply { text=c.group; textSize=12f; setTextColor(muted) })
   row.setOnClickListener { try { player?.setMediaItem(MediaItem.fromUri(Uri.parse(c.url))); player?.prepare(); player?.play(); setStatus("Reproduzindo: ${c.name}") } catch(e:Exception) { setStatus("Não foi possível iniciar este fluxo.") } }
   listBox.addView(row,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(7) })
  }
 }
 private fun fetch(address:String):String {
  val conn=URL(address).openConnection() as HttpURLConnection
  conn.connectTimeout=15000; conn.readTimeout=20000; conn.requestMethod="GET"; conn.setRequestProperty("User-Agent","BrazTVPlayer/1.0")
  try { val code=conn.responseCode; val stream=if(code in 200..299) conn.inputStream else conn.errorStream
   val body=BufferedReader(InputStreamReader(stream)).use { it.readText() }
   if(code !in 200..299) throw IllegalStateException("HTTP $code")
   return body
  } finally { conn.disconnect() }
 }
 private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
 private fun edit(h:String)=EditText(this).apply { hint=h; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize=14f; setSingleLine(true); setPadding(dp(12),dp(8),dp(12),dp(8)); backgroundTintList=android.content.res.ColorStateList.valueOf(red); layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply { topMargin=dp(8) } }
 private fun button(label:String, action:()->Unit)=Button(this).apply { text=label; isAllCaps=false; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(red); textSize=13f; setOnClickListener { action() }; layoutParams=LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(8) } }
 private fun setStatus(msg:String) { runOnUiThread { if(::status.isInitialized) status.text=msg } }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 override fun onDestroy() { player?.release(); player=null; io.shutdown(); super.onDestroy() }
}
